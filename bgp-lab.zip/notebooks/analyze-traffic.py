from pybatfish.client.commands import *
from pybatfish.question import bfq
from pybatfish.datamodel.flow import HeaderConstraints, PathConstraints

# Connect to Batfish
bf_session.host = 'batfish'

# Create or select network and snapshot
bf_set_network("cloud-bgp")
bf_init_snapshot("/home/jovyan/snapshots/cloud-bgp", name="snapshot1", overwrite=True)

# View BGP session status
bgp_status = bfq.bgpSessionStatus().answer().frame()
print("BGP Session Status:\n", bgp_status)

# Check reachability from on-prem to Tata's advertised subnet
reachability = bfq.reachability(
    pathConstraints=PathConstraints(startLocation="onprem-router"),
    headers=HeaderConstraints(dstIps="10.100.1.0/24")
).answer().frame()

print("Reachability from on-prem to Tata:\n", reachability)